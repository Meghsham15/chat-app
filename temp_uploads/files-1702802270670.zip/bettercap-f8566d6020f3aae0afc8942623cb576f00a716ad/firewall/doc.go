// Package firewall contains the OS specific implementation of the FirewallManager interface.
package firewall
