// Package session contains code to manage the interactive session, modules, environment, etc.
package session
