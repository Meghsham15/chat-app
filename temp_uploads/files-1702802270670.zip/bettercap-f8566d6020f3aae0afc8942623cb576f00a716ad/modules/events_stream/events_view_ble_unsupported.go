// +build windows darwin

package events_stream

import (
	"github.com/bettercap/bettercap/session"
)

func (mod *EventsStream) viewBLEEvent(e session.Event) {

}
