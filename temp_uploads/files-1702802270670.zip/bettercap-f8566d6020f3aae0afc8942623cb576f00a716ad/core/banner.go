package core

const (
	Name    = "bettercap"
	Version = "2.24"
	Author  = "Simone 'evilsocket' Margaritelli"
	Website = "https://bettercap.org/"
)
