// Package core contains basic utility functions.
package core
